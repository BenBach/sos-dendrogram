package com.aliasi.test.unit.chunk;

import com.aliasi.test.unit.BaseTestCase;

public class TokenShapeChunkerTest extends BaseTestCase {

    public void testOne() {
	// need something more than a stub here!!!
    }

}
